import Vue from 'vue'
import Router from 'vue-router'
// import HelloWorld from '@/components/HelloWorld'
const FindPageComponent = () => import('@/page/findPage/index')
const WxPage = () => import('@/page/wxPage/index')
const MinePage = () => import('@/page/minePage/index')
const PhonePeople = () => import('@/page/phonePeople/index')

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      name: '微信',
      component: WxPage
    },
    {
      path: '/findPage',
      name: '发现',
      component: FindPageComponent
    },
    {
      path: '/minePage',
      name: '我的',
      component: MinePage
    },
    {
      path: '/phonePeople',
      name: '通讯录',
      component: PhonePeople
    },
  ]
})
