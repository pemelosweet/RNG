<template>
    <div>
     <span id="left" v-show="mm" @click="houtui">←</span>
        <div class="topbar">
            {{titles}} 
            <i v-show="status">+</i>
        </div>
        <router-view/>
        <Nav/>
    </div>
</template>
<script>
import Nav from '@/components/navButton/index';
export default {
    name: 'index',
    data: () => ({
        titles: '', 
        status: true,
        mm: true,
    }),
    components: {
        Nav
    },
    watch: {
        '$route' (to, from) {
           console.log(to.name)
           this.titles = to.name;
           if (this.titles == '微信' || this.titles == '通讯录') {
               this.status = true;
           } else {
               this.status = false;
           }
           if (this.titles == '微信' ) {
               this.mm = false;
           } else {
               this.mm = true;
           }
        }
    },
    methods: {
        houtui(){
            this.$router.go(-1)
        }
    },
}
</script>
<style>
#left{
      background:pink;
      width:30px;
      height:30px;
      color:red;
      position:absolute;
      top:10px;
      left:10px;
      z-index:10;
      text-align:center;
      line-height: 25px;
       border-radius:50%; 
    }
    .topbar{
        background: #000;
        width: 100%;
        height: 50px;
        text-align: center;
        line-height: 50px;
        color: #fff;
        position: fixed;
        top: 0;
        color:green;
    };
    
</style>