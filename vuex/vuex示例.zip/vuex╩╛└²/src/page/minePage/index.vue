<template>
        <div>
            <p>{{name}}</p>
        </div>
    </template>
    <script>
    export default {
        name: 'minePage',
        data: () => ({
            name: '我是我的页面'
        })
    }
    </script>
    <style scoped>
    @import url('./index.css');
    </style>