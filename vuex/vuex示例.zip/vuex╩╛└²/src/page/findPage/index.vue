<template>
    <div>
        <p>{{name}}</p>
        <p>{{count}}</p>
        <button @click='add'>+</button>
        <button @click='jian'>-</button>
    </div>
</template>
<script>
    import { mapState ,mapMutations } from 'vuex'
export default {
    name: 'findPage',
    data: () => ({
        name: '我是寻找页面'
    }),
    computed: {
        ...mapState(["count"])
    },
    methods: {
        ...mapMutations(['increment']),
        add(){
            this.increment(true)
        },
        jian(){
            this.increment(false) 
        }
    },
}
</script>
<style scoped>
@import url('./index.css');
</style>