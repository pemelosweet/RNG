<template>
    <div class="war">
        <ul class="nav">
            <li v-for="item in list" :key="item.id" @click="toPage(item.path)">
                {{item.name}}
            </li>
        </ul>
    </div>
</template>
<script>
export default {
    name: 'navButton',
    data: () => ({
        name: '我是寻找页面',
        list: [
            {
                name: '微信',
                id: 0,
                path: '/'
            },
            {
                name: '通讯录',
                id: 1,
                path: 'phonePeople'
            },
            {
                name: '发现',
                id: 2,
                path: 'findPage'
            },
            {
                name: '我的',
                id: 3,
                path: 'minePage'
            },
        ]
    }),
    methods: {
        toPage(path) {
            this.$router.push(path)
        }
    },
}
</script>
<style >
@import url('./index.css');
</style>