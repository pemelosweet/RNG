import Vuex from 'vuex'
import Vue from 'vue'
Vue.use(Vuex)


const store = new Vuex.Store({
    state: {
      count: 0
    },
    mutations: {
      increment (state, flag) {
        console.log(flag)
        flag ?  state.count++ :  state.count--
      }
    }
})
export default store;