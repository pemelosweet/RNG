module.exports = {
  NODE_ENV: '"production"',
  ENV_CONFIG: '"test"',
  BASE_API: '"/"'
}
