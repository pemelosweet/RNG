module.exports = {
  NODE_ENV: '"production"',
  ENV_CONFIG: '"prod"',
  // BASE_API: '"http://192.168.1.222:7300/mock/5a34e1a57778fa25b09c375f/drs"'
  BASE_API: '"/"' // 测试
  // BASE_API: '"http://11.129.98.141:81"' // 中心
  // BASE_API: '"http://11.129.93.1:61443"' // 生产
  // BASE_API: '"http://192.168.200.63:8771"' // 开发
}
