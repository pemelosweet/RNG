module.exports = {
  NODE_ENV: '"development"',
  ENV_CONFIG: '"dev"',
  // BASE_API: '"http://10.10.121.134:8771"'
  BASE_API: '""'
  // BASE_API: '"http://192.168.50.116:10101"' // 沈帅本地'
  // BASE_API: '"http://11.129.98.141"'
}
