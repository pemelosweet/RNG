module.exports = {
  NODE_ENV: '"production"',
  ENV_CONFIG: '"dev"',
  BASE_API: '"http://192.168.200.63:8771"'
  // BASE_API: '"http://192.168.50.88:8771"'
}