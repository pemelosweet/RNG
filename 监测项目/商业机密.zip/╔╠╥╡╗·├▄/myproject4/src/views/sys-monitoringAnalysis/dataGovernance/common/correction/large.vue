<template>
  <div class="largewrap">

    <el-form :model="largeForm" ref="largeForm" :rules="largeRules" label-width="200px">
      <!-- 第二块 -->
      <el-row :gutter="20" v-if="hasData !== null">
        <el-col :span="24" style="font-weight:bold; font-size:16px; margin:0 0 15px 22px;">基本信息</el-col>
        <el-col :span="24">
          <el-form-item label="报告机构：" prop="rinm">
            <el-autocomplete v-model="largeForm.rinm" value-key="rinm" placeholder="报告机构" v-if="isView" :fetch-suggestions="querySearchRinm" :trigger-on-focus="false" @select="handleRinmSelect" style="width: 60%;"></el-autocomplete>
            <span v-if="!isView">{{ largeForm.rinm }}</span>
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="更正完成时限：" prop="correctLimitTime">
            <el-date-picker v-model="largeForm.correctLimitTime" value-format="yyyy-MM-dd" type="date" placeholder="选择更正完成时限" :picker-options="updataPickerOptions" style="width:100% !important;">
            </el-date-picker>
          </el-form-item>
        </el-col>

        <el-col :span="24">
          <el-form-item label="更正填报要求：" prop="correctAsk">
            <el-input type="textarea" v-model="largeForm.correctAsk" placeholder="最大长度为1000位" maxlength="1000" show-word-limit rows="5"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="待更正大额交易总数：" prop="askNum">
            <el-input v-if="isView" type="text" v-model="largeForm.askNum" maxlength="1" placeholder="待更正可疑交易总数不能大于5"></el-input>
            <span v-if="!isView">{{largeForm.askNum}}</span>
          </el-form-item>
        </el-col>

        <el-col :span="24" style="font-weight:bold; font-size:16px; margin:0 0 15px 22px;">交易信息</el-col>
        <el-table v-if="isAddTradeBtn" :data="largeForm.list" class="tableWarp">
          <el-table-column label="原客户号" min-width="120" prop="ocnm">
            <template slot-scope="scope">
              <el-form-item :prop="'list.'+scope.$index+'.ocnm'" :rules="largeRules.ocnm">
                <el-input v-model="scope.row.ocnm" v-if="isView" placeholder="最大长度为32位" @blur="showFont(scope)" maxlength="32"></el-input>
                <span v-if="!isView && scope.$index !== 0">{{scope.row.ocnm}}</span>
                <span v-if="!isView && scope.$index === 0">{{scope.row.ocnm}}</span>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column label="原大额交易发生日期" width="200" prop="otdt">
            <template slot-scope="scope">
              <el-form-item :prop="'list.'+scope.$index+'.otdt'" :rules="largeRules.otdt">
                <el-date-picker v-model="scope.row.otdt" type="date" value-format="yyyy-MM-dd" @change="showFont(scope)"  placeholder="选择日期"  v-if="isView">
                </el-date-picker>
                <el-date-picker v-if="!isView && scope.$index !== 0" v-model="scope.row.otdt" disabled type="date" value-format="yyyyMMdd" format="yyyy-MM-dd" placeholder="选择日期">
                </el-date-picker>
                <el-date-picker v-if="!isView && scope.$index === 0" v-model="scope.row.otdt" disabled type="date" value-format="yyyyMMdd" format="yyyy-MM-dd" placeholder="选择日期">
                </el-date-picker>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column label="原大额交易特征代码" width="110" prop="otcd">
            <template slot-scope="scope">
              <el-form-item :prop="'list.'+scope.$index+'.otcd'" :rules="largeRules.otcd">
                <el-select v-model="scope.row.otcd" v-if="isView" style="width: 100%;"  @change="showFont(scope)" clearable>
                  <el-option v-for="(item,index) in largeOptions" :label="item.codeId"  :value="item.codeId"  :key="index"></el-option>
                </el-select>
                <el-select v-model="scope.row.otcd" v-if="!isView && scope.$index !== 0" disabled style="width: 100%;" clearable>
                  <el-option v-for="(item,index) in largeOptions" :label="item.codeId" :value="item.codeId" :key="index"></el-option>
                </el-select>
                <el-select v-model="scope.row.otcd" v-if="!isView && scope.$index === 0" disabled style="width: 100%;" clearable>
                  <el-option v-for="(item,index) in largeOptions" :label="item.codeId" :value="item.codeId" :key="index"></el-option>
                </el-select>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column label="原业务标识号" prop="otic" min-width="160">
            <template slot-scope="scope">
              <el-form-item :prop="'list.'+scope.$index+'.otic'" :rules="largeRules.otic">
                <el-input v-model="scope.row.otic" v-if="isView" @blur="showFont(scope)"  placeholder="最大长度为256位" maxlength="256"></el-input>
                <span v-if="!isView && scope.$index !== 0">{{scope.row.otic}}</span>
                <span v-if="!isView && scope.$index === 0">{{scope.row.otic}}</span>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column label="待更正字段" prop="item" width="400">
            <template slot-scope="scope">
              <el-form-item :prop="'list.'+scope.$index+'.item'" :rules="largeRules.item"
               class="change_length">
                <el-select multiple placeholder="请选择" v-model="scope.row.item" @change="baoFont(scope.row)"  style="width: 100%;">
                  <el-option v-for="(sItem, index) in scope.row.filedOptions" :key="index" :label="sItem.name" :value="sItem.code">
                  </el-option>
                </el-select>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column label="操作" v-if="isView" width="100">
            <template slot-scope="scope">
              <el-button type="text" @click="removeRow(scope)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
        <el-table v-else :data="largeForm.list" class="tableWarp">
          <el-table-column label="原客户号" min-width="120" prop="ocnm">
            <template slot-scope="scope">
              <el-form-item :prop="'list.'+scope.$index+'.ocnm'" :rules="largeRules.ocnm">
                <el-input v-model="scope.row.ocnm" v-if="isView" placeholder="最大长度为32位" maxlength="32"></el-input>
                <span v-if="!isView && scope.$index !== 0">{{scope.row.ocnm}}</span>
                <span v-if="!isView && scope.$index === 0">{{scope.row.ocnm}}</span>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column label="原大额交易发生日期" width="200" prop="otdt">
            <template slot-scope="scope">
              <el-form-item :prop="'list.'+scope.$index+'.otdt'" :rules="largeRules.otdt">
                <el-date-picker v-model="scope.row.otdt" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" v-if="isView">
                </el-date-picker>
                <el-date-picker v-if="!isView && scope.$index !== 0" v-model="scope.row.otdt" disabled type="date" value-format="yyyyMMdd" format="yyyy-MM-dd" placeholder="选择日期">
                </el-date-picker>
                <el-date-picker v-if="!isView && scope.$index === 0" v-model="scope.row.otdt" disabled type="date" value-format="yyyyMMdd" format="yyyy-MM-dd" placeholder="选择日期">
                </el-date-picker>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column label="原大额交易特征代码" width="110" prop="otcd">
            <template slot-scope="scope">
              <el-form-item :prop="'list.'+scope.$index+'.otcd'" :rules="largeRules.otcd">
                <el-select v-model="scope.row.otcd" v-if="isView" style="width: 100%;" clearable>
                  <el-option v-for="(item,index) in largeOptions" :label="item.codeId" :value="item.codeId" :key="index"></el-option>
                </el-select>
                <el-select v-model="scope.row.otcd" v-if="!isView && scope.$index !== 0" disabled style="width: 100%;" clearable>
                  <el-option v-for="(item,index) in largeOptions" :label="item.codeId" :value="item.codeId" :key="index"></el-option>
                </el-select>
                <el-select v-model="scope.row.otcd" v-if="!isView && scope.$index === 0" disabled style="width: 100%;" clearable>
                  <el-option v-for="(item,index) in largeOptions" :label="item.codeId" :value="item.codeId" :key="index"></el-option>
                </el-select>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column label="原业务标识号" prop="otic" min-width="160">
            <template slot-scope="scope">
              <el-form-item :prop="'list.'+scope.$index+'.otic'" :rules="largeRules.otic">
                <el-input v-model="scope.row.otic" v-if="isView" placeholder="最大长度为256位" maxlength="256"></el-input>
                <span v-if="!isView && scope.$index !== 0">{{scope.row.otic}}</span>
                <span v-if="!isView && scope.$index === 0">{{scope.row.otic}}</span>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column label="待更正字段" prop="item" width="400">
            <template slot-scope="scope">
              <el-form-item :prop="'list.'+scope.$index+'.item'" :rules="largeRules.item"
               class="change_length">
                <el-select multiple placeholder="请选择" v-model="scope.row.item" @change="baoFont(scope.row)"  style="width: 100%;">
                  <el-option v-for="(sItem, index) in filedOptions" :key="index" :label="sItem.name" :value="sItem.code">
                  </el-option>
                </el-select>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column label="操作" v-if="isView" width="100">
            <template slot-scope="scope">
              <el-button type="text" @click="removeRow(scope)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
        <el-pagination :current-page="pageInfo.current" :page-sizes="[10, 20, 30, 40]" :page-size="pageInfo.size" layout="total, sizes, prev, pager, next, jumper" :total="pageInfo.total" background @size-change="handleSizeChange" @current-change="handleCurrentChange" />
        <el-button type="primary" @click="addRow" v-if="isAddTradeBtn" style="margin-top: 10px;">增加大额交易</el-button>
        <div class="dialog-footer">
          <el-button @click="onCancel">取 消</el-button>
          <el-button type="primary" @click="callWorkFlow" :loading="spLoading">提交审批</el-button>
        </div>
      </el-row>
      <div v-else style="text-align: center; height:100px; line-height: 100px;">暂无数据</div>
    </el-form>

  </div>
</template>

<script>
import {
  addCorrectData,
  addOtherCorrectData,
  getInfo,
  getFiled
} from '@/api/sys-monitoringAnalysis/dataGovernance/artificialCorrection/launch'
import { getRinmList } from '@/api/sys-monitoringAnalysis/statisticForm/large.js'
import { dataTask } from '@/api/sys-monitoringAnalysis/dataGovernance/crossbodyAlignment/index'
import { mapGetters } from 'vuex'
import { isValidInput, isValidBlank, onlyNumberValidate } from '@/utils/formValidate.js'

export default {
  props: {
    dialogVisible: {
      type: Boolean
    },
    correctParams: {
      type: Object
    },
    closeLoading: {
      type: Boolean
    }
  },
  data() {
    return {
      updataPickerOptions: { // 更正时间 选中今天及以后
        disabledDate(time) {
          return time.getTime() < Date.now() - 8.64e7
        }
      },
      // tradeIdLengthInfo: '',
      largeVisible: this.dialogVisible,
      rinmOptions: [], // 报告机构列表
      largeOptions: [], // 获取交易特征代码
      largeForm: {
        rinm: '',
        ricd: '',
        correctLimitTime: '',
        correctAsk: '',
        askNum: '',
        list: [
          {
            ocnm: '',
            otdt: '',
            otcd: '',
            otic: '',
            item: [],
            filedOptions: []
          }
        ]
      },
      pageList: [],
      largeRules: {
        rinm: [{ required: true, message: '内容不能为空', trigger: 'blur' }],
        // ricd: [{ required: true, message: '内容不能为空', trigger: 'blur' }],
        correctLimitTime: [{ required: true, message: '内容不能为空', trigger: 'change' }],
        correctAsk: [
          { required: true, message: '内容不能为空', trigger: 'blur' },
          { validator: isValidBlank, trigger: 'blur' },
          { max: 1000, message: '最大长度为1000位', trigger: 'blur' }
        ],
        askNum: [
          { required: true, message: '内容不能为空', trigger: 'blur' },
          { validator: onlyNumberValidate, trigger: 'blur' }
        ],
        ocnm: [
          { required: true, message: '内容不能为空', trigger: 'blur' },
          { validator: isValidInput, trigger: 'blur' },
          { max: 32, message: '最大长度为32位', trigger: 'blur' }
        ],
        otdt: [{ required: true, message: '内容不能为空', trigger: 'change' }],
        otcd: [{ required: true, message: '内容不能为空', trigger: 'change' }],
        otic: [
          { required: true, message: '内容不能为空', trigger: 'blur' },
          { validator: isValidInput, trigger: 'blur' },
          { max: 256, message: '最大长度为256位', trigger: 'blur' }
        ],
        item: [{ required: true, message: '内容不能为空', trigger: 'change' }]
      },
      filedOptions: [],
      tradeId: null,
      correctType: null,
      listObj: {},
      isView: true,
      isAddTradeBtn: true,
      hasData: null,
      tempDataSrc: '',
      tempIndustry: '',
      spLoading: false,
      pageInfo: {
        current: 1,
        size: 10,
        total: null
      },
      fenObj: []
    }
  },
  computed: {
    ...mapGetters(['roles', 'businessFlag', 'workFlow2business'])
  },
  watch: {
    businessFlag(val) {
      if (val) this.nextStep()
      this.$store.dispatch('changeFlag', false)
    },
    dialogVisible(val) {
      this.fenObj = []
      this.filedOptions = []
      this.largeForm.list = [
        {
          ocnm: '',
          otdt: '',
          otcd: '',
          otic: '',
          item: [],
          filedOptions: []
        }
      ]
      this.pageList = [
        {
          ocnm: '',
          otdt: '',
          otcd: '',
          otic: '',
          item: [],
          filedOptions: []
        }
      ]
      this.pageInfo.current = 1
      this.pageInfo.size = 10
      this.pageInfo.total = null
      if (val) this.getData()
    }
  },
  mounted() {
    this.fenObj = []
    this.getData()
  },
  methods: {
    showFont(scope) {
      // if (this.largeForm.ricd === '') {
      //   this.$message({
      //     type: 'error',
      //     message: '请先选择报告机构'
      //   })
      //   scope.row.ocnm === ''
      //   scope.row.otcd === ''
      //   scope.row.otdt === ''
      //   scope.row.otic === ''
      //   return false
      // }
      if (scope.row.ocnm !== '' && scope.row.otcd !== '' && scope.row.otdt !== '' && scope.row.otic !== '' && this.largeForm.ricd !== '') {
        const otdt = scope.row.otdt.split('-').join('')
        const paramsObj = {
          ricd: this.largeForm.ricd,
          tradeType: '0',
          dataSrc: '',
          reportBody: '',
          bhCsnm: scope.row.ocnm,
          bhCode: scope.row.otcd,
          bhDate: otdt,
          bhLogo: scope.row.otic
        }
        getFiled(paramsObj)
          .then(res => {
          // 获取字段列表
            if (res.code === 200) {
              scope.row.filedOptions = res.data
            }
          })
          .catch(() => {})
      }
    },
    baoFont(scope) {
      if (this.fenObj.length > 0) {
        for (var i = 0; i < this.fenObj.length; i++) {
          // 如果数组中的id等于当前选择数据的id那么就把当前scope的值赋值给数组中的值
          if (scope.tradeId === this.fenObj[i].tradeId) {
            this.fenObj[i] = scope
            this.fenObj.splice(i, 1)
            i--
          }
        }
      }
      console.log(scope, 'fenObj-----2')
      this.fenObj.push(scope)
    },
    // 分页
    // 切换分页条数
    handleSizeChange(size) {
      this.pageInfo.size = size
      if (this.isAddTradeBtn) {
        this.largeForm.list = this.pageList.slice((this.pageInfo.current - 1) * this.pageInfo.size, (this.pageInfo.current - 1) * this.pageInfo.size + this.pageInfo.size)
      } else {
        // this.getData()
        this.getTradeInfo(this.pageInfo.current, this.pageInfo.size)
      }
    },
    // 点击切换分页
    handleCurrentChange(pageNum) {
      this.pageInfo.current = pageNum
      if (this.isAddTradeBtn) {
        this.largeForm.list = this.pageList.slice((pageNum - 1) * this.pageInfo.size, (pageNum - 1) * this.pageInfo.size + this.pageInfo.size)
      } else {
        // this.getData()
        this.getTradeInfo(this.pageInfo.current, this.pageInfo.size)
      }
    },
    callWorkFlow() {
      this.$refs.largeForm.validate(validate => {
        if (validate) {
          // *********jyl-改前代码***********
          if (this.largeForm.list.length.toString() !== this.largeForm.askNum.toString()) {
            this.$message({
              type: 'error',
              message: '待更正大额交易总数与交易信息不匹配,请仔细检查'
            })
            return false

          // ************jyl-改后代码****************
          // console.log(this.fenObj.length, this.largeForm.askNum)
          // console.log('---------------------------------------------------------')
          // if (this.fenObj.length.toString() !== this.largeForm.askNum.toString()) {
          //   this.$message({
          //     type: 'error',
          //     message: '待更正大额交易总数与交易信息不匹配,请仔细检查'
          //   })
          //   return false
          } else {
            // this.largeVisible = false
            // this.$emit('dialogState', this.largeVisible)
            setTimeout(() => {
              this.$store.dispatch('workFlow', { configCode: 'correctApproval' })
              this.$store.dispatch('openWorkFlow', true)
            }, 500)
          }
        } else {
          return false
        }
      })
    },
    getData() {
      this.spLoading = this.closeLoading
      if (this.$refs.largeForm) {
        this.$refs.largeForm.resetFields()
      }
      this.tradeId = this.correctParams.tradeId
      this.correctType = this.correctParams.correctType
      this.tempIndustry = this.correctParams.industry
      // this.correctParams.pageNum = this.pageInfo.current
      // this.correctParams.pageSize = this.pageInfo.size
      this.isAddTradeBtn = true
      this.isView = true
      this.tempDataSrc = ''
      if (this.correctParams.organ === '5') {
        // 通过来源判断是其他还是人工补正发起模块
        if (this.tradeId) {
          // 判断有tradeid和没填tradeid
          this.getTradeInfo(this.pageInfo.current, this.pageInfo.size) // 发起人工补正
          this.getCharacteInfo() // 获取交易特征代码
          this.isAddTradeBtn = false
          this.isView = false
        } else {
          this.largeForm.list = [
            {
              ocnm: '',
              otdt: '',
              otcd: '',
              otic: '',
              item: [],
              filedOptions: []
            }
          ]
          this.pageList = [
            {
              ocnm: '',
              otdt: '',
              otcd: '',
              otic: '',
              item: [],
              filedOptions: []
            }
          ]
          this.pageInfo.total = 1
          this.largeForm.rinm = ''
          this.largeForm.ricd = ''
          this.largeForm.askNum = ''
          this.isView = true
          this.isAddTradeBtn = true
          this.hasData = ['0']
          this.getCharacteInfo() // 获取交易特征代码
        }
      } else {
        this.getTradeInfo(this.pageInfo.current, this.pageInfo.size)
        this.isAddTradeBtn = false
        this.isView = false
        this.getCharacteInfo() // 获取交易特征代码
      }
    },
    getTradeInfo(current, size) {
      // 获取交易内容
      getInfo(this.correctParams, current, size)
        .then(res => {
          if (res.code === 200) {
            this.hasData = res.data.list
            this.pageInfo.total = res.data.total
            if (this.hasData !== null) {
              if (this.hasData.length > 0) {
                this.largeForm.list = []
                this.largeForm.rinm = res.data.list[0].rinm
                this.largeForm.ricd = res.data.list[0].ricd

                const obj = Object.assign([], res.data.list)

                obj.map(item => {
                  if (item) {
                    this.listObj = {
                      tradeId: item.tradeId,
                      ocnm: item.csnm,
                      otdt: item.htdt,
                      otcd: item.crcd,
                      otic: item.ticd,
                      item: []
                    }
                    this.largeForm.list.push(this.listObj)
                  }
                })
                for (let index = 0; index < this.fenObj.length; index++) {
                  for (let ind = 0; ind < this.largeForm.list.length; ind++) {
                    if (this.fenObj[index].tradeId === this.largeForm.list[ind].tradeId) {
                      this.largeForm.list[ind].item = this.fenObj[index].item
                    }
                  }
                }
                this.largeForm.askNum = res.data.total
                this.tempDataSrc = res.data.list[0].dataSrc
                this.getFiledInfo(this.largeForm.ricd, this.tempDataSrc)
              } else {
                return false
              }
            }
          }
        })
        .catch(() => {})
    },
    querySearchRinm(query, cb) {
      if (query !== '') {
        const paramsObj = {
          region: 'all',
          rinm: query
        }
        getRinmList(paramsObj).then(res => {
          if (res.code === 200) {
            cb(res.data)
          }
        })
      } else {
        // this.rinmData = []
      }
    },
    handleRinmSelect(item) {
      if (item) {
        this.largeForm.ricd = item.ricd
        this.largeForm.list = [
          {
            ocnm: '',
            otdt: '',
            otcd: '',
            otic: '',
            item: [],
            filedOptions: []
          }
        ]
        this.pageList = [
          {
            ocnm: '',
            otdt: '',
            otcd: '',
            otic: '',
            item: [],
            filedOptions: []
          }
        ]
        // this.getFiledInfo(this.largeForm.ricd)
      }
    },
    getFiledInfo(ricd, dataSrc) {
      const paramsObj = {
        ricd: ricd,
        tradeType: '0',
        dataSrc: dataSrc
      }
      getFiled(paramsObj)
        .then(res => {
          // 获取字段列表
          if (res.code === 200) {
            this.filedOptions = res.data
          }
        })
        .catch(() => {})
    },
    getCharacteInfo() {
      const typeId = 'CRCD'
      dataTask(typeId)
        .then(res => {
          if (res.code === 200) {
            this.largeOptions = res.data
          }
        })
        .catch()
    },
    resetForm(formName) {
      this.$refs[formName].resetFields()
    },
    onCancel() {
      // 取消
      this.spLoading = false
      this.largeVisible = false
      this.$emit('dialogState', this.largeVisible)
      this.fenObj = []
    },
    nextStep() {
      // 提交
      this.spLoading = true
      if (this.correctParams.organ === '5') {
        if (this.tradeId) {
          this.otherCorrectSubmit()
        } else {
          this.correctSubmit()
        }
      } else {
        this.otherCorrectSubmit()
      }
    },
    correctSubmit() {
      const paramsObj = {
        correctType: this.correctType,
        tradeId: this.tradeId,
        reportCode: this.largeForm.ricd,
        correctLimitTime: this.largeForm.correctLimitTime,
        correctAsk: this.largeForm.correctAsk,
        askNum: this.largeForm.askNum,
        highTrades: this.largeForm.list,
        workflow: this.workFlow2business
      }
      addCorrectData(paramsObj)
        .then(res => {
          if (res.code === 200) {
            this.spLoading = false

            this.largeForm.list = [
              {
                ocnm: '',
                otdt: '',
                otcd: '',
                otic: '',
                item: [],
                filedOptions: []
              }
            ]
            this.$message({
              type: 'success',
              message: '提交成功！'
            })
            this.resetForm('largeForm')
            this.largeVisible = false
            this.$emit('dialogState', this.largeVisible)
          } else {
            this.spLoading = false
            this.$message.error('提交失败！')
          }
        })
        .catch(() => {
          this.spLoading = false
        })
    },
    otherCorrectSubmit() {
      this.largeForm.list.forEach(e => {
        const fileds = e.item
        this.itemObj = {
          item: fileds
        }
      })
      const paramsObj = {
        correctType: this.correctType,
        tradeId: this.tradeId,
        reportCode: this.largeForm.ricd,
        problemSource: this.correctParams.organ,
        correctLimitTime: this.largeForm.correctLimitTime,
        correctAsk: this.largeForm.correctAsk,
        industry: this.tempIndustry,
        askNum: this.largeForm.askNum,
        reportBody: this.largeForm.rinm,
        highTrades: this.fenObj,
        workflow: this.workFlow2business
      }
      addOtherCorrectData(paramsObj)
        .then(res => {
          if (res.code === 200) {
            this.spLoading = false

            this.largeForm.list = [
              {
                ocnm: '',
                otdt: '',
                otcd: '',
                otic: '',
                item: [],
                filedOptions: []
              }
            ]
            this.$message({
              type: 'success',
              message: '提交成功！'
            })
            this.largeVisible = false
            this.$emit('dialogState', this.largeVisible)
          } else {
            this.spLoading = false
            this.$message.error('提交失败！')
          }
        })
        .catch(() => {
          this.spLoading = false
        })
    },
    addRow() {
      var _data = {
        ocnm: '',
        otdt: '',
        otcd: '',
        otic: '',
        item: [],
        filedOptions: []
      }
      this.largeForm.list.push(_data)
      this.pageList.push(_data)
      const len = this.largeForm.list.length
      if (len > this.pageInfo.size) {
        this.largeForm.list = this.pageList.slice((this.pageInfo.current - 1) * this.pageInfo.size, this.pageInfo.size)
      }
      if (len > 1000) {
        this.largeForm.list.splice(Number(len - 1), 1)
        this.$message({
          message: '最多可以添加1000条交易',
          type: 'warning'
        })
      }
      this.pageInfo.total = this.pageList.length
    },
    removeRow(scope) {
      if (this.pageList.length === 1) {
        this.$message({
          message: '最少保留1条交易',
          type: 'warning'
        })
        return false
      }
      const index = scope.$index
      this.$confirm('确定要删除此交易吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          this.largeForm.list.splice(index, 1)
          this.pageList.splice((this.pageInfo.current - 1) * this.pageInfo.size, 1)
          if (this.pageList.length % this.pageInfo.size === 0) {
            this.pageInfo.current--
          }
          this.largeForm.list = this.pageList.slice((this.pageInfo.current - 1) * this.pageInfo.size, (this.pageInfo.current - 1) * this.pageInfo.size + this.pageInfo.size)
          this.pageInfo.total = this.pageList.length
        })
        .catch(() => {})
    }
  }
}
</script>

<style lang="scss">
.largewrap {
  .inforow {
    padding-bottom: 15px;
    font-weight: bold;
  }
  .el-table .el-table__row td {
    padding: 20px 0;
    .cell {
      height: 100%;
      .el-form-item {
        margin-bottom: 20px;
        .el-form-item__content {
          margin-left: 0px !important;
        }
      }
      overflow: inherit;
    }
  }
  .dialog-footer {
    padding-top: 10px;
    text-align: right;
  }
  .el-table__header-wrapper .cell::before {
    content: '*';
    color: #f00;
    margin-right: 4px;
  }
}
</style>
