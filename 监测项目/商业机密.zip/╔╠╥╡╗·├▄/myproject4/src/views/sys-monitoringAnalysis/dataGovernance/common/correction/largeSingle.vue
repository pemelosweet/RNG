<template>
  <div class="largewrap">
    <el-form :model="form" ref="form" label-width="160px">
      <el-row :gutter="20">
        <el-col :span="12">
          <div class="title">人工补正要求通知</div>
          <div class="noticeMain">
            <el-col :span="24" style="font-weight:bold; font-size:16px; margin:0 0 15px 22px;">基本信息</el-col>
            <el-row>
              <el-form-item label="报告机构：">{{ form.reportBody }}</el-form-item>
            </el-row>
            <el-row>
              <el-form-item label="更正完成时限：">
                <el-date-picker v-model="form.correctLimitTime" value-format="yyyyMMdd" format="yyyy-MM-dd" type="date" placeholder="选择更正完成时限" :picker-options="updataPickerOptions" disabled>
                </el-date-picker>
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item label="更正填报要求：">{{ form.correctAsk }}</el-form-item>
            </el-row>
            <el-row>
              <el-form-item label="待更正大额交易总数：">{{ form.askNum }}</el-form-item>
            </el-row>
            <div>
              <el-col :span="24" style="font-weight:bold; font-size:16px; margin:0 0 15px 22px;">交易信息</el-col>
              <el-table :data="form.list">
                <el-table-column type="index" label="序号"></el-table-column>
                <el-table-column label="原客户号" prop="ocnm" width="100"></el-table-column>
                <el-table-column label="原大额交易发生日期" prop="otdt" min-width="160">
                  <template slot-scope="scope">
                    <el-date-picker v-model="scope.row.otdt" style="width: 80% !important;" value-format="yyyyMMdd" format="yyyy-MM-dd" type="date" placeholder="选择更正完成时限" :picker-options="updataPickerOptions" disabled>
                    </el-date-picker>
                  </template>
                </el-table-column>
                <el-table-column label="原大额交易特征代码" prop="otcd" width="120">
                  <template slot-scope="scope">
                    <el-select v-model="scope.row.otcd" disabled style="width: 100%;">
                      <el-option v-for="(item,index) in largeOptions" :label="item.codeName" :value="item.codeId" :key="index"></el-option>
                    </el-select>
                  </template>
                </el-table-column>
                <el-table-column label="原业务标识号" prop="otic" width="100"></el-table-column>
                <el-table-column label="待更正字段" prop="item" min-width="160">
                  <template slot-scope="scope">
                    <el-form-item :prop="'list.'+scope.$index+'.item'" class="change_length">
                      <el-select multiple placeholder="请选择" v-model="scope.row.item" disabled>
                        <el-option v-for="(sItem, index) in filedOptions" :key="index" :label="sItem.name" :value="sItem.code">
                        </el-option>
                      </el-select>
                    </el-form-item>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div>
        </el-col>
        <el-col :span="12">
          <div class="title">原交易详情</div>
          <div class="noticeMain">
            <TradeDetail :detailOptions="detailOptions"></TradeDetail>
          </div>

          <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="pageNum" :page-size="pageSize" layout="total, prev, pager, next, jumper" :total="total">
          </el-pagination>
        </el-col>
      </el-row>
      <div class="dialog-footer">
        <el-button @click="onCancel">返 回</el-button>
      </div>
    </el-form>
  </div>
</template>

<script>
import TradeDetail from '@/views/sys-monitoringAnalysis/dataGovernance/common/tradeDetail/components/tradeDetail'
import { dataTask } from '@/api/sys-monitoringAnalysis/dataGovernance/crossbodyAlignment/index'
import { getFiled, getInfo } from '@/api/sys-monitoringAnalysis/dataGovernance/artificialCorrection/launch'
import { getViewInfo } from '@/api/sys-monitoringAnalysis/dataGovernance/artificialCorrection/notice'

export default {
  props: {
    dialogVisible: {
      type: Boolean
    },
    correctParams: {
      type: Object
    }
  },
  components: {
    TradeDetail
  },
  data() {
    return {
      updataPickerOptions: { // 更正时间 选中今天及以后
        disabledDate(time) {
          return time.getTime() < Date.now() - 8.64e7
        }
      },
      form: {
        reportBody: '',
        reportCode: '',
        correctLimitTime: '',
        correctAsk: '',
        list: [],
        askNum: ''
      },
      largeOptions: [], // 获取交易特征代码
      detailOptions: null,
      correctId: '',
      disabled: true,
      filedOptions: [],
      pageNum: 1,
      pageSize: 1,
      total: null,
      contentList: null,
      largeVisible: this.dialogVisible
    }
  },
  watch: {
    dialogVisible(val) {
      if (val) this.getData()
    }
  },
  mounted() {
    this.getData()
  },
  methods: {
    getData() {
      if (this.$refs.form) {
        this.$refs.form.resetFields()
      }
      getViewInfo(this.correctParams.correctId).then(res => {
        if (res.code === 200) {
          this.form = res.data.report
          if (res.data.report.reportCode) {
            getInfo(this.correctParams, 1, 10).then(res1 => {
              if (res1.code === 200 && res1.data.list !== null) {
                this.getFiledInfo(res.data.report.reportCode, res1.data.list[0].dataSrc)
              }
            })
            // this.getFiledInfo(res.data.report.reportCode)
          }
          this.getCharacteInfo()
          if (res.data.list.length > 0) {
            this.contentList = res.data.list
            const obj = JSON.parse(res.data.list[0])
            this.detailOptions = obj.trade
            this.total = res.data.list.length
          } else {
            this.detailOptions = '无数据'
          }
          this.form.askNum = this.form.list.length
        }
      }).catch()
    },
    getFiledInfo(ricd, dataSrc) {
      const paramsObj = {
        ricd: ricd,
        tradeType: '0',
        dataSrc: dataSrc
      }
      getFiled(paramsObj)
        .then(res => {
          // 获取字段列表
          if (res.code === 200) {
            this.filedOptions = res.data
          }
        })
        .catch(() => {})
    },
    getCharacteInfo() {
      const typeId = 'CRCD'
      dataTask(typeId)
        .then(res => {
          if (res.code === 200) {
            this.largeOptions = res.data
          }
        })
        .catch()
    },
    onCancel() {
      this.largeVisible = false
      this.$emit('dialogState', this.largeVisible)
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.getPagInfo(val)
    },
    handleCurrentChange(val) {
      this.pageNum = val
      this.getPagInfo(val)
    },
    getPagInfo(val) {
      console.log(this.contentList)
      if (this.contentList[parseInt(val) - 1]) {
        this.detailOptions = JSON.parse(this.contentList[parseInt(val) - 1]).trade
        console.log(this.detailOptions)
      }
    }
  }
}
</script>

<style lang="scss">
.largewrap {
  .title {
    padding-bottom: 15px;
    padding-left: 15px;
    font-weight: 500;
    font-size: 16px;
  }
  .noticeMain {
    // width: 100%;
    height: 700px;
    overflow-x: hidden;
    overflow-y: auto;
    padding: 15px;
    margin: 15px;
    border: 1px solid #eeeeee;
    font-size: 14px;
  }
  .el-table .el-table__row td {
    .cell {
      height: 100%;
      .el-form-item {
        margin-bottom: 0;
        .el-form-item__content {
          margin-left: 0px !important;
        }
      }
    }
  }
  .change_length {
    .el-select__tags >span {
      display: block!important;
      width: 100%;
    }
    .el-form-item__content {
      margin-left: 0!important;
    }
  }
  .el-table__header-wrapper .cell::before {
    content: '*';
    color: #f00;
    margin-right: 4px;
  }
}
</style>
