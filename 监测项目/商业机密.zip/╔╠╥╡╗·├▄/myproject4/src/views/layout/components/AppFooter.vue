<template>
  <div class="app-footer">
    中国反洗钱监测分析中心 Copyright ©️ 2017
  </div>
</template>

<script>
export default {
  name: 'AppFooter'
}
</script>

<style lang="scss">
.app-footer{
  // position: absolute;
  background-color: #fff;
  width: 100%;
  border-top:1px solid #eee;
  height: 60px;
  line-height: 60px;
  text-align: center;
  // bottom: -60px;
  // right:0;
}
</style>

