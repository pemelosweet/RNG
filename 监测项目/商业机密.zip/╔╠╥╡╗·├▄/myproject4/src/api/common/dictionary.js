import request from '@/utils/request'

// 数据字典
export function dictionaryList(typeId) {
  return request({
    url: 'code-manage/codesys/code-detail',
    methods: 'get',
    params: typeId
  })
}
