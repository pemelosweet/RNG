import request from '@/utils/request'

export function routerJump() {
  return request({
    url: '/monitor/statistics/code/knowledge-forum',
    method: 'get'
  })
}
