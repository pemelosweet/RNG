import request from '@/utils/request'

// 查询
export function getDataList(params) {
  return request({
    url: 'monitor/reportClue/total',
    method: 'get',
    params: params
  })
}
