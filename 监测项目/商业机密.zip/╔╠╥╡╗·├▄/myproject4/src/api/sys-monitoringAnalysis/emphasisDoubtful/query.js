import request from '@/utils/request'

// 查询线索
export function getList(params) {
  return request({
    url: 'monitor/keysus',
    method: 'get',
    params: params
  })
}
