import request from '@/utils/request'
// 分支机构
export function branch(params) {
  return request({
    url: 'code-manage/codesys/code-detail',
    method: 'get',
    params: params
  })
}
