import request from '@/utils/request'

export function getOptions(params) {
  return request({
    url: 'monitor/match/select-managerName',
    method: 'get',
    data: params
  })
}
