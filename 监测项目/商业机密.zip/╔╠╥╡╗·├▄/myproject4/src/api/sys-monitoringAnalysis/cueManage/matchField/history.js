import request from '@/utils/request'

// 线索管理-匹配信息查询 信息查询-查询按钮
export function getList(params) {
  return request({
    url: 'monitor/information/history-manage',
    method: 'get',
    params: params
  })
}
