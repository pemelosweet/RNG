import request from '@/utils/request'

export function getList(paramsObj) { // 标注列表
  return request({
    url: 'monitor/tagging',
    method: 'get',
    params: paramsObj
  })
}

export function addTagData(paramsObj) {
  return request({
    url: 'monitor/tagging',
    method: 'post',
    data: paramsObj
  })
}
