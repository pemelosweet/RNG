import request from '@/utils/request'

export function getList(paramsObj) {
  return request({
    url: 'monitor/governance/interagency/task-history/sync8a',
    method: 'get',
    params: paramsObj
  })
}

export function viewResultData(compId) {
  return request({
    url: 'monitor/governance/interagency/task-history/' + compId + '/result-info/sync8a',
    method: 'get'
  })
}
