import request from '@/utils/request'

export function getList(paramsObj) {
  return request({
    url: '/monitor/governance/approval/approval/cleanHistory',
    method: 'get',
    params: paramsObj
  })
}
