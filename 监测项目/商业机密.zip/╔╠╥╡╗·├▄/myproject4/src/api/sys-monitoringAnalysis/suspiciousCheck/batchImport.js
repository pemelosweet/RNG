import request from '@/utils/request'
export function fileRepeat(params) {
  return request({
    url: 'monitor/keySusReport/upFile/' + params,
    method: 'post'
  })
}
