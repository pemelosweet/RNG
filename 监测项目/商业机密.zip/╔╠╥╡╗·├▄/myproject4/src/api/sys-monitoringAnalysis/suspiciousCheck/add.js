import request from '@/utils/request'

// 保存信息
export function onSubmit(params) {
  return request({
    url: 'monitor/keySusReport',
    method: 'post',
    data: params
  })
}

// 保存信息
// export function userBranch(id) {
//   return request({
//     url: 'codesys/code-detail/detail/FZJG/A1000163000174',
//     method: 'post',
//     data: params
//   })
// }
