import request from '@/utils/request'
// 分支列表
export function getTotal(params) {
  return request({
    url: '/monitor/reportLeads/total',
    method: 'get',
    params: params
  })
}
// // 按交易发生地
// export function getTotalArea(params) {
//   return request({
//     url: '/monitor/reportLeads/totalArea',
//     method: 'get',
//     params: params
//   })
// }
// // 报告机构统计
// export function getReportBody(params) {
//   return request({
//     url: '/monitor/reportLeads/totalReportBody',
//     method: 'get',
//     params: params
//   })
// }

// // 按分支机构上报份数统计
// export function getBranch(params) {
//   return request({
//     url: '/monitor/reportLeads/totalBranch',
//     method: 'get',
//     params: params
//   })
// }

// // 按分析研判意见统计
// export function getAnalys(params) {
//   return request({
//     url: '/monitor/reportLeads/totalAnalys',
//     method: 'get',
//     params: params
//   })
// }

// // 按审核会议名称统计
// export function getMeetingName(params) {
//   return request({
//     url: '/monitor/reportLeads/totalMeetingName',
//     method: 'get',
//     params: params
//   })
// }

// // 按办理结果统计
// export function getResult(params) {
//   return request({
//     url: '/monitor/reportLeads/totalTransactionResult',
//     method: 'get',
//     params: params
//   })
// }

