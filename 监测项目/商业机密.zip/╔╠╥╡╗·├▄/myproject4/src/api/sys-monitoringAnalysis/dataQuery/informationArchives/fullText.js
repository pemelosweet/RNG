import request from '@/utils/request'
// 情报类文件档案查询--全文检索
export function getList() {
  return request({
    url: '',
    method: ''
  })
}
