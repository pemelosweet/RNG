import request from '@/utils/request'

// 保存举报单信息
export function paperApi(params) {
  return request({
    url: '/monitor/fill-report/save',
    method: 'post',
    data: params
  })
}
