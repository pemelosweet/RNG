import request from '@/utils/request'

export function statisticsApi(params) {
  return request({
    url: '/monitor/fill-report/statistics',
    method: 'get',
    params: params
  })
}
