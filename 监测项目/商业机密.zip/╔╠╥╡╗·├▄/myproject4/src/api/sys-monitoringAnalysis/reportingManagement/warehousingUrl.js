import request from '@/utils/request'

// 查询已入库举报单列表信息
export function warehousingIe(params) {
  return request({
    url: '/monitor/fill-report/select-storage',
    method: 'get',
    params: params
  })
}
// 查询已入库举报单列表信息
export function warehousingIe1(params) {
  return request({
    url: '/monitor/fill-report/select-storage1',
    method: 'get',
    params: params
  })
}

