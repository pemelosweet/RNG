import request from '@/utils/request'

// 获取列表
export function getListData(params) {
  return request({
    url: 'monitor/listwarn/warningtask/sync8a',
    method: 'post',
    data: params
  })
}
// 查看获取信息
export function getInfoData(id) {
  return request({
    url: 'monitor/listwarn/warningtask/sync8a/' + id,
    method: 'get'
  })
}

// 分配
// 分配
export function giveObjSuspInfo(params) {
  return request({
    url: 'monitor/findByReportDispose/Redistribute',
    method: 'post',
    data: params
  })
}
