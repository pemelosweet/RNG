import request from '@/utils/request'
// 可疑 -- 提交回调-数据更新
export function findAnalysisUpdate(id, params) {
  return request({
    url: '/monitor/listwarn/warningtask/update?id=' + id,
    method: 'put',
    data: params
  })
}
