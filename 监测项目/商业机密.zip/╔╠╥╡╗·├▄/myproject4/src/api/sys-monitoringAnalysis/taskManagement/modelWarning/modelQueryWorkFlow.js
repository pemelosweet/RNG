import request from '@/utils/request'
// 模型平台 -- 提交回调-数据更新
export function modelAnalysisUpdate(id, params) {
  return request({
    url: '/monitor/modelWarning/update?mEwpcId=' + id,
    method: 'put',
    data: params
  })
}
