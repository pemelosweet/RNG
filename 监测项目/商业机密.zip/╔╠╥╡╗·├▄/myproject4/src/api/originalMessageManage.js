import request from '@/utils/request'

export function getList() {
  return request({
    url: 'dataReceive/originalMessageManage',
    method: 'get'
  })
}
export function dataBackData() {
  return request({
    url: 'dataReceive/dataBack',
    method: 'get'
  })
}
