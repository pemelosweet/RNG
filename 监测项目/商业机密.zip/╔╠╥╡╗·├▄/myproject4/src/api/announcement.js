import request from '@/utils/request'

export function getList() {
  return request({
    url: 'businessManage/announcement',
    method: 'get'
  })
}

export function editData() {
  return request({
    url: 'businessManage/announcementEdit',
    method: 'get'
  })
}
