import request from '@/utils/request'

export function getList() {
  return request({
    url: '/inboxs',
    method: 'post'
  })
}
