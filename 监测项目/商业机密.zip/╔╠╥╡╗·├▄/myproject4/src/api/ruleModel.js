import request from '@/utils/request'

export function getEruleList(params) {
  return request({
    url: '/sys-monitoringAnalysis/ruleModel',
    method: 'get',
    params
  })
}

export function getExcutingList(params) {
  return request({
    url: '/sys-monitoringAnalysis/ruleModel',
    method: 'get',
    params
  })
}
