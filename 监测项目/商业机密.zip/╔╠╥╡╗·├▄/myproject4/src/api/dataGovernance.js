import request from '@/utils/request'

export function getScanningindex(query) {
  return request({
    url: '/dataGovernance/scanningMonitor',
    method: 'get',
    params: query
  })
}
