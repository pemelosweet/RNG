import request from '@/utils/request'

export function getList() {
  return request({
    url: 'dataSubmit/newBigDeals',
    method: 'get'
  })
}
